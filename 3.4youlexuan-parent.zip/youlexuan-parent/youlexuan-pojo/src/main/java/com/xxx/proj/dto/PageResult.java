package com.xxx.proj.dto;

import java.io.Serializable;
import java.util.List;

//TODO:PageResult必须序列号，实现Serializable接口
public class PageResult implements Serializable {
    private long total; //总条数
    private List rows; //返回分页数据

    public PageResult() {
    }

    public PageResult(long total, List rows) {
        this.total = total;
        this.rows = rows;
    }

    public long getTotal() {
        return total;
    }

    public void setTotal(long total) {
        this.total = total;
    }

    public List getRows() {
        return rows;
    }

    public void setRows(List rows) {
        this.rows = rows;
    }
}
