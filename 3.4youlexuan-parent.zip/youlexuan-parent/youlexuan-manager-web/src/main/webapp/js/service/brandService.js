//js服务层
app.service("brandService", function ($http) {
    this.selectOptions = function () {
        return $http.get("../brand/selectOptions.do");
    };
    this.findAll = function () {
        return $http.get("../brand/findAll.do");
    };
    this.reloadList = function (entity, pageNum, pageSize) {
        return $http.post("../brand/findPage.do?pageNum=" + pageNum + "&pageSize=" + pageSize, entity);
    };
    this.findById = function (id) {
        return $http.get("../brand/findById.do?id=" + id);
    };
    this.remove = function (ids) {
        return $http.get("../brand/remove.do?ids=" + ids);
    }
    this.save = function (entity) {
        var url;
        if (entity.id == null) {//新增
            url = "../brand/add.do";
        } else {//修改
            url = "../brand/modify.do"
        }
        return $http.post(url, entity);
    }
});