//js控制层
app.controller("brandController", function (brandService, $controller, $scope) {
    //TODO 把baseController的$scope,复制到brandController的$scope中
    $controller("baseController", {$scope: $scope});

    $scope.findAll = function () {
        brandService.findAll().success(function (response) {
            $scope.list = response;
        });
    };
    $scope.searchEntity = {};//查询对象
    $scope.reloadList = function () {
        //$scope.paginationConf.itemsPerPage 每页条数
        //$scope.paginationConf.currentPage 当前页码
        //http://localhost:9002/brand/findPage.do?pageNum=1&pageSize=5
        //TODO 条件查询时，这里要改成POST请求，同时添加查询对象searchEntity
        brandService.reloadList($scope.searchEntity, $scope.paginationConf.currentPage, $scope.paginationConf.itemsPerPage)
            .success(function (response) {
                $scope.list = response.rows;
                $scope.paginationConf.totalItems = response.total;
            })
    };
    $scope.save = function () {
        //$http.post(url, $scope.entity)
        brandService.save($scope.entity).success(function (response) {
            // 如果成功，刷新页面
            alert(response.message);
            if (response.success) {
                $scope.reloadList();
            }
        })
    }
    $scope.findById = function (id) {
        brandService.findById(id).success(function (response) {
            $scope.entity = response;
        })
    }

    $scope.remove = function () {
        //$http.get("../brand/remove.do?ids=" + $scope.selectIds)
        alert($scope.selectIds)
        brandService.remove($scope.selectIds).success(function (response) {
            alert(response.message);
            if (response.success) {
                $scope.reloadList();
                $scope.selectIds = [];
            }
        })
    }
})