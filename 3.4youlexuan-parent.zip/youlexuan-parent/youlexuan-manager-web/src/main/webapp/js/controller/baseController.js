app.controller("baseController", function ($scope) {
    //分页处理
    $scope.paginationConf = {
        currentPage: 1, //当前页码
        itemsPerPage: 10, //每页条数
        perPageOptions: [10, 20, 30], //每页条数选项
        onChange: function () { //当选项变动时调用的处理方法
            $scope.reloadList();
        }
    };

    $scope.selectIds = [];
    //TODO 使用内置变量$event来获取checkbox的选中状态$event.target.checked
    $scope.updateSelection = function ($event, id) {
        //如果复选框是选中状态，则添加，否则移除
        if ($event.target.checked) {
            $scope.selectIds.push(id);
        } else {
            var idx = $scope.selectIds.indexOf(id);
            $scope.selectIds.splice(idx, 1);
        }
        // alert(JSON.stringify($scope.selectIds))
    }

    $scope.reloadList = function () {
        $scope.search($scope.paginationConf.currentPage, $scope.paginationConf.itemsPerPage);
    }
})