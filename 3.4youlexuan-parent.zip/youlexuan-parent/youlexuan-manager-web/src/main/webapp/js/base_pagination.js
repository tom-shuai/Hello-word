//需要分页时使用
var app = angular.module("youlexuan", ["pagination"]);