package com.xxx.proj.controller;

import com.alibaba.dubbo.config.annotation.Reference;
import com.xxx.proj.dto.PageResult;
import com.xxx.proj.dto.Result;
import com.xxx.proj.pojo.TbBrand;
import com.xxx.proj.service.TbBrandService;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/brand")
public class TbBrandController {
    @Reference(timeout = 10000)
    private TbBrandService brandService;

    @RequestMapping("/findAll")
    public List<TbBrand> findAll() {
        return brandService.findAll();
    }

    @RequestMapping("/findPage")
    public PageResult findPage(@RequestBody TbBrand brand, int pageNum, int pageSize) {
        return brandService.findByPage(brand, pageNum, pageSize);
    }

    @RequestMapping("/add")
    public Result add(@RequestBody TbBrand brand) {
        try {
            brandService.add(brand);
            return new Result(true, "新增品牌成功");
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return new Result(false, "新增品牌失败");
    }

    @RequestMapping("/findById")
    public TbBrand findById(long id) {
        return brandService.findById(id);
    }

    @RequestMapping("/modify")
    public Result modify(@RequestBody TbBrand brand) {
        try {
            brandService.modify(brand);
            return new Result(true, "修改品牌成功");
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return new Result(false, "修改品牌失败");
    }

    @RequestMapping("/remove")
    public Result remove(Long[] ids) {
        try {
            brandService.remove(ids);
            return new Result(true, "删除品牌成功");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return new Result(false, "删除品牌失败");
    }

    @RequestMapping("/selectOptions")
    public List<Map> selectOptions() {
        return brandService.selectOptions();
    }
}
