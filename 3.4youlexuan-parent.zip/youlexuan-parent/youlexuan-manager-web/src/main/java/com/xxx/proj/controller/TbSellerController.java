package com.xxx.proj.controller;

import com.alibaba.dubbo.config.annotation.Reference;
import com.xxx.proj.pojo.TbSeller;
import com.xxx.proj.service.TbSellerService;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/seller")
public class TbSellerController {
    @Reference(timeout = 10000)
    private TbSellerService tbSellerService;

    @RequestMapping("/findAll")
    public List<TbSeller> findAll() {
        return tbSellerService.findAll();
    }
}
