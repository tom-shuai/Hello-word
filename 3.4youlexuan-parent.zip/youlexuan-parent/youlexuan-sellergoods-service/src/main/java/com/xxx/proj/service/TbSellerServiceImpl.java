package com.xxx.proj.service;

import com.alibaba.dubbo.config.annotation.Service;
import com.xxx.proj.mapper.TbSellerMapper;
import com.xxx.proj.pojo.TbSeller;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

@Service(timeout = 10000)
public class TbSellerServiceImpl implements TbSellerService {
    @Autowired
    private TbSellerMapper tbSellerMapper;

    public List<TbSeller> findAll() {
        return tbSellerMapper.selectByExample(null);
    }
}
