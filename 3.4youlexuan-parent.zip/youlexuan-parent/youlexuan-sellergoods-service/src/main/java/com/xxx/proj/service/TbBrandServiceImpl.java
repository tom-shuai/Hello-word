package com.xxx.proj.service;

import com.alibaba.dubbo.config.annotation.Service;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.xxx.proj.dto.PageResult;
import com.xxx.proj.mapper.TbBrandMapper;
import com.xxx.proj.pojo.TbBrand;
import com.xxx.proj.pojo.TbBrandExample;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Map;

@Service(timeout = 10000)
public class TbBrandServiceImpl implements TbBrandService {
    @Autowired
    TbBrandMapper brandMapper;

    @Override
    public List<TbBrand> findAll() {
        return brandMapper.selectByExample(null);
    }

    @Override
    public PageResult findByPage(int pageNum, int pageSize) {
        //调用插件，进行分页
        PageHelper.startPage(pageNum, pageSize);
        //TODO:注意：这里的Page类-import com.github.pagehelper.Page;
        Page<TbBrand> page = (Page<TbBrand>) brandMapper.selectByExample(null);
        //http://localhost:9002/brand/findPage.do?pageNum=1&pageSize=5
        return new PageResult(page.getTotal(), page.getResult());
    }

    @Override
    public PageResult findByPage(TbBrand brand, int pageNum, int pageSize) {
        PageHelper.startPage(pageNum, pageSize);
        TbBrandExample example = new TbBrandExample();
        TbBrandExample.Criteria criteria = example.createCriteria();//TODO ctrl+alt+v生成等号左边的声明部分
        if (brand != null) {
            if (brand.getName() != null && brand.getName().length() > 0) {
                criteria.andNameLike("%" + brand.getName() + "%");//模糊查询
            }
            if (brand.getFirstChar() != null && brand.getFirstChar().length() > 0) {
                criteria.andFirstCharEqualTo(brand.getFirstChar()); //等值比较
            }
        }
        Page<TbBrand> page = (Page<TbBrand>) brandMapper.selectByExample(example);
        return new PageResult(page.getTotal(), page.getResult());
    }

    @Override
    public int add(TbBrand brand) {
        return brandMapper.insert(brand);
    }

    @Override
    public TbBrand findById(long id) {
        return brandMapper.selectByPrimaryKey(id);
    }

    @Override
    public int modify(TbBrand brand) {
        return brandMapper.updateByPrimaryKey(brand);
    }

    @Override
    public int remove(Long[] ids) {
        for (Long id : ids) {
            brandMapper.deleteByPrimaryKey(id);
        }
        return 1;
    }

    @Override
    public List<Map> selectOptions() {
        return brandMapper.selectOptions();
    }


}
