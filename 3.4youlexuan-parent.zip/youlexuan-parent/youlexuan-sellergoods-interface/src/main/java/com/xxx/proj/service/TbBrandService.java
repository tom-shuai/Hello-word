package com.xxx.proj.service;

import com.xxx.proj.dto.PageResult;
import com.xxx.proj.pojo.TbBrand;

import java.util.List;
import java.util.Map;

public interface TbBrandService {
    //ctrl+alt+b 跳转到实现类
    public List<TbBrand> findAll();

    /**
     * @param pageNum  页数
     * @param pageSize 每页条数
     * @return
     */
    public PageResult findByPage(int pageNum, int pageSize);

    public PageResult findByPage(TbBrand brand, int pageNum, int pageSize);

    public int add(TbBrand brand);

    public TbBrand findById(long id);

    public int modify(TbBrand brand);

    public int remove(Long[] ids);

    public List<Map> selectOptions();

}
