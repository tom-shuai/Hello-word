package com.xxx.proj.service;

import com.xxx.proj.pojo.TbSeller;

import java.util.List;

public interface TbSellerService {
    public List<TbSeller> findAll();
}
