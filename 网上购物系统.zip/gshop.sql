/*
Navicat MySQL Data Transfer

Source Server         : localhost_3307
Source Server Version : 50018
Source Host           : localhost:3307
Source Database       : gshop

Target Server Type    : MYSQL
Target Server Version : 50018
File Encoding         : 65001

Date: 2019-06-20 10:32:32
*/

SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Table structure for `adminuser`
-- ----------------------------
DROP TABLE IF EXISTS `adminuser`;
CREATE TABLE `adminuser` (
  `uid` int(11) NOT NULL auto_increment,
  `username` varchar(255) default NULL,
  `password` varchar(255) default NULL,
  PRIMARY KEY  (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of adminuser
-- ----------------------------
INSERT INTO adminuser VALUES ('3', 'admin', 'admin');

-- ----------------------------
-- Table structure for `category`
-- ----------------------------
DROP TABLE IF EXISTS `category`;
CREATE TABLE `category` (
  `cid` int(11) NOT NULL auto_increment,
  `cname` varchar(255) default NULL,
  PRIMARY KEY  (`cid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of category
-- ----------------------------
INSERT INTO category VALUES ('1', '手机');
INSERT INTO category VALUES ('2', '厨房卫浴');
INSERT INTO category VALUES ('3', '生活电器');
INSERT INTO category VALUES ('4', '电脑办公');
INSERT INTO category VALUES ('5', '电脑办公');
INSERT INTO category VALUES ('6', '电视影音');
INSERT INTO category VALUES ('7', '冰箱/洗衣机');
INSERT INTO category VALUES ('8', '空调');

-- ----------------------------
-- Table structure for `categorysecond`
-- ----------------------------
DROP TABLE IF EXISTS `categorysecond`;
CREATE TABLE `categorysecond` (
  `csid` int(11) NOT NULL auto_increment,
  `csname` varchar(255) default NULL,
  `cid` int(11) default NULL,
  PRIMARY KEY  (`csid`),
  KEY `FK936FCAF21DB1FD15` (`cid`),
  CONSTRAINT `FK936FCAF21DB1FD15` FOREIGN KEY (`cid`) REFERENCES `category` (`cid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of categorysecond
-- ----------------------------
INSERT INTO categorysecond VALUES ('1', '手机通讯', '1');
INSERT INTO categorysecond VALUES ('2', '手机配件', '1');
INSERT INTO categorysecond VALUES ('3', '充值', '1');
INSERT INTO categorysecond VALUES ('4', '烟灶套餐', '2');
INSERT INTO categorysecond VALUES ('5', '电热水器', '2');
INSERT INTO categorysecond VALUES ('6', '燃气热水器', '2');
INSERT INTO categorysecond VALUES ('7', '电饭煲', '3');
INSERT INTO categorysecond VALUES ('9', '微波炉', '3');
INSERT INTO categorysecond VALUES ('10', '取暖器', '3');
INSERT INTO categorysecond VALUES ('11', '笔记本', '4');
INSERT INTO categorysecond VALUES ('12', '平板电脑', '4');
INSERT INTO categorysecond VALUES ('13', '台式电脑', '4');
INSERT INTO categorysecond VALUES ('14', '摄影摄像', '5');
INSERT INTO categorysecond VALUES ('15', '智能设备', '5');
INSERT INTO categorysecond VALUES ('16', '影音娱乐', '5');
INSERT INTO categorysecond VALUES ('17', '55英寸电视', '6');
INSERT INTO categorysecond VALUES ('18', '4K超高清', '6');
INSERT INTO categorysecond VALUES ('19', '国产电视', '6');
INSERT INTO categorysecond VALUES ('20', '对开门冰箱', '7');
INSERT INTO categorysecond VALUES ('21', '滚筒洗衣机', '7');
INSERT INTO categorysecond VALUES ('22', '干衣机', '7');
INSERT INTO categorysecond VALUES ('23', '壁挂式空调', '8');
INSERT INTO categorysecond VALUES ('24', '柜式空调', '8');
INSERT INTO categorysecond VALUES ('25', '移动空调', '8');

-- ----------------------------
-- Table structure for `orderitem`
-- ----------------------------
DROP TABLE IF EXISTS `orderitem`;
CREATE TABLE `orderitem` (
  `itemid` int(11) NOT NULL auto_increment,
  `count` int(11) default NULL,
  `subtotal` double default NULL,
  `pid` int(11) default NULL,
  `oid` int(11) default NULL,
  PRIMARY KEY  (`itemid`),
  KEY `FKE8B2AB6166C01961` (`oid`),
  KEY `FKE8B2AB6171DB7AE4` (`pid`),
  KEY `FKE8B2AB6140ACF87A` (`oid`),
  CONSTRAINT `FKE8B2AB6140ACF87A` FOREIGN KEY (`oid`) REFERENCES `orders` (`oid`),
  CONSTRAINT `FKE8B2AB6171DB7AE4` FOREIGN KEY (`pid`) REFERENCES `product` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of orderitem
-- ----------------------------

-- ----------------------------
-- Table structure for `orders`
-- ----------------------------
DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `oid` int(11) NOT NULL auto_increment,
  `total` double default NULL,
  `ordertime` datetime default NULL,
  `state` int(11) default NULL,
  `name` varchar(20) default NULL,
  `phone` varchar(20) default NULL,
  `addr` varchar(50) default NULL,
  `uid` int(11) default NULL,
  PRIMARY KEY  (`oid`),
  KEY `FKC3DF62E5AA3D9C7` (`uid`),
  CONSTRAINT `FKC3DF62E5AA3D9C7` FOREIGN KEY (`uid`) REFERENCES `user` (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of orders
-- ----------------------------

-- ----------------------------
-- Table structure for `product`
-- ----------------------------
DROP TABLE IF EXISTS `product`;
CREATE TABLE `product` (
  `pid` int(11) NOT NULL auto_increment,
  `pname` varchar(255) default NULL,
  `market_price` double default NULL,
  `shop_price` double default NULL,
  `image` varchar(255) default NULL,
  `pdesc` varchar(255) default NULL,
  `is_hot` int(11) default NULL,
  `pdate` datetime default NULL,
  `csid` int(11) default NULL,
  PRIMARY KEY  (`pid`),
  KEY `FKED8DCCEFB9B74E02` (`csid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of product
-- ----------------------------
INSERT INTO product VALUES ('72', '小米MI 小米9 超广角微距三摄 8GB+128GB 深空灰 全网通', '2999', '2799', 'products/s1001.jpg', '索尼4800万超广角微距三摄，骁龙855旗舰处理器，前置光学指纹识别！', '1', '2019-06-18 23:29:17', '1');
INSERT INTO product VALUES ('73', '荣耀（honor）荣耀20 8GB+128GB', '2999', '2699', 'products/s1002.jpg', '全网通版 幻影蓝 4800万超广角AI四摄 3200W美颜自拍 ', '1', '2019-06-18 23:35:33', '1');
INSERT INTO product VALUES ('74', 'Apple iPhone XS Max 256G  银色 移动联通电信4G手机', '8988', '8888', 'products/s1003.jpg', '银色 移动联通电信4G手机 iPhone XS Max配备6.5英寸显示屏，', '1', '2019-06-18 23:39:23', '1');
INSERT INTO product VALUES ('75', 'Apple iPhone XR 128G 黄色 移动联通电信4G手机', '5588', '5088', 'products/s1004.jpg', '黄色 移动联通电信4G手机“哪一面都是亮点”iPhone XR配备6.1', '1', '2019-06-18 23:41:54', '1');
INSERT INTO product VALUES ('76', '华为畅享 MAX (ARS-AL00) 4GB+128GB 珍珠屏杜比全景声', '1999', '1888', 'products/s1005.jpg', '双卡双待 幻夜黑集攒赢海尔家电+华为P30，【7.12英寸大屏，杜比全景声，5000mA超长续航】', '1', '2019-06-18 23:46:38', '1');
INSERT INTO product VALUES ('77', '荣耀(honor) 荣耀V20 标配版 全网通 6GB+128GB 幻影蓝 ', '2299', '2099', 'products/s1006.jpg', '麒麟980芯片，魅眼全视屏，4800万AI超清摄影！', '1', '2019-06-18 23:48:04', '1');
INSERT INTO product VALUES ('78', '华为手机P20 Pro (CLT-AL01) 6GB+64GB 全面屏徕卡三摄', '4488', '4088', 'products/s1007.jpg', '全网通 双卡双待 樱粉金集攒赢海尔家电+华为P30，【4000万徕卡三摄/DxO评分过百/夜神之眼/真AI/极光色樱粉金渐变设计', '1', '2019-06-18 23:49:18', '1');
INSERT INTO product VALUES ('79', '小米 红米Redmi K20 4800万超广角三摄 8GB+256GB 冰川蓝', '2259', '2059', 'products/s1008.jpg', '全网通4G 双卡双待Redmik20系列旗舰新品， 4800万超广角三摄', '1', '2019-06-18 23:50:36', '1');
INSERT INTO product VALUES ('80', '荣耀（honor）荣耀10 全面屏AI摄影手机 ', '3000', '2888', 'products/s1009.jpg', '尊享版 6GB+128GB 幻影蓝移动联通电信4G手机', '1', '2019-06-18 23:53:12', '1');
INSERT INTO product VALUES ('81', 'OPPO Reno 全面屏拍照手机 6GB+128GB', '2799', '2599', 'products/s1010.jpg', '全网通 4G手机 双卡双待 星云紫\r\n4800万超清像素，全景屏，NFC，全隐藏式摄像头', '0', '2019-06-18 23:55:43', '1');
INSERT INTO product VALUES ('82', '罗马仕（ROMOSS）sense6P LED数显屏', '99', '88', 'products/p1001.jpg', '移动电源/充电宝 20000毫安 白色 双输出 手机通用', '1', '2019-06-18 23:58:42', '2');
INSERT INTO product VALUES ('83', ' 充值类型： 话费充值 流量充值', '99.99', '98.99', 'products/c1001.jpg', '支持移动/联通/电信/极信\r\n', '1', '2019-06-19 00:02:45', '3');
INSERT INTO product VALUES ('84', '帅康（Sacon）CXW-200-T8001+35C烟灶套装', '2799', '2699', 'products/y1001.jpg', '高性价比烟灶组合，瞬吸油烟无残留！4.2KW大火力！自动熄火保护，钢化玻璃面板煤气灶！', '1', '2019-06-19 00:06:56', '4');
INSERT INTO product VALUES ('85', '美的（Midea） 50升 2100W 经济适用', '999', '899', 'products/d1001.jpg', '【国美自营】50升15A1升级款！防电墙！沐浴更安心！高热水输出率！节能省电！前置电源开关，简约操作！8年包修！2100W功率加热快', '1', '2019-06-19 00:09:13', '5');
INSERT INTO product VALUES ('86', '樱花(SAKURA) 12升燃气热水器新智能恒温宽屏触控', '2199', '1999', 'products/r1001.jpg', '【樱花品质保证！】好评送爱仕达锅具两件套，宽屏触控，无氧铜水箱！数码精控分段燃烧！控温更准确！此款防冻机型！每年免费安检服务！（本产品只适用天然气）更多惊喜咨询客服', '1', '2019-06-19 00:10:53', '6');
INSERT INTO product VALUES ('87', '美的(Midea) 电饭煲 匠银聚能厚釜内胆', '298', '279', 'products/df1001.jpg', '新品】4L容量 匠银聚能厚釜 24小时智能预约 时尚数码显示屏 微压蒸汽阀 金属拉丝机身 3D钻石纹理上盖设计', '1', '2019-06-19 00:12:16', '7');
INSERT INTO product VALUES ('88', '美的(Midea) M1-L202B', '389', '369', 'products/wb1001.jpg', '20L平板快捷加热，一键美味即享！智能菜单，简单易上手！快速解冻，锁住营养！易洁内胆，电子除味，告别难闻异味！', '1', '2019-06-19 00:13:46', '8');
INSERT INTO product VALUES ('89', '美的（Midea）11片电油汀NY2011-16JW取暖器', '699', '588', 'products/ql1001.jpg', '配赠加湿盒+折叠衣架！全屋升温，三挡任调！高温导热油，3条油路设计，高效升温，舒适防烫！', '1', '2019-06-19 00:14:57', '9');
INSERT INTO product VALUES ('90', 'Apple MacBook Air 13.3英寸笔记本电脑', '6749', '6666', 'products/bj1001.jpg', ' 银色（Core i5处理器/8GB内存/128GB固态硬盘 MQD32CH/A）\r\n纤巧轻薄 超长续航', '1', '2019-06-19 00:16:21', '11');
INSERT INTO product VALUES ('91', 'Apple iPad 平板电脑 2018年款9.7英寸', '3272', '3099', 'products/pb001.jpg', '128G Wifi版/A10 芯片/Retina显示屏/Touch ID MR7K2CH/A）银色', '1', '2019-06-19 00:17:35', '12');
INSERT INTO product VALUES ('92', '戴尔DELL灵越3670-R18N9G游戏台式电脑', '5099', '4999', 'products/ts1001.jpg', 'i5-8400 8G 1T DVD WIFI 蓝牙 键鼠 三年上门）(GTX1060-3G电竞独显 19.5英寸整机', '1', '2019-06-19 00:18:54', '13');
INSERT INTO product VALUES ('93', '索尼（SONY）ILCE-7M3 ', '13499', '13399', 'products/sy1001.jpg', '全画幅微单数码相机 单机身 约2420万有效像素 4K视频 5轴防抖', '1', '2019-06-19 00:20:09', '14');
INSERT INTO product VALUES ('94', '漫步者（EDIFIER）HECATE GM450环绕立体声', '179', '159', 'products/zn1001.jpg', '双动圈 低音炮震动入耳式手机电脑游戏耳机带线控手游耳麦 黑红\r\n魔兽级游戏耳塞，电脑手机通用，四单元专业音效，可插拔双麦设计，听声辨位！', '1', '2019-06-19 00:21:20', '15');
INSERT INTO product VALUES ('95', '全新Beats Studio3 Wireless无线降噪耳机', '2488', '2388', 'products/yy1001.jpg', '蓝牙头戴主动消噪耳麦(桀骜黑红（十周年纪念版）)\r\n【畅享音乐 拒绝噪音 下单赠耳机支架】', '1', '2019-06-19 00:23:08', '16');
INSERT INTO product VALUES ('96', '索尼(SONY) KD-55X8000G 55英寸', '7999', '6999', 'products/551001.jpg', '特丽魅彩显示技术 4K迅锐图像处理引擎PRO 智能超高清电视 黑色\r\n索尼55英寸 特丽魅彩显示技术 4K迅锐图像处理引擎PRO 智能超高清电视', '1', '2019-06-19 00:24:25', '17');
INSERT INTO product VALUES ('97', '创维（SKYWORTH）55V7 55英寸4K超高清HDR', '3999', '3899', 'products/4k1001.jpg', '20核A73芯片 AI人工智能语音 网络WIFI 液晶平板电视机\r\n【创维好物节】18号，限时特惠，到手不高于1699！4K超高清，智能语音操作，8G大存储，A73架构，畅快追剧丰', '1', '2019-06-19 00:25:31', '18');
INSERT INTO product VALUES ('98', '海尔(Haier) LE39B3300W ', '2999', '2699', 'products/gc1001.jpg', '39英寸 高清 智能护眼 震撼音效 LED平板电视（黑色）39英寸高清节能 广色域A+面板 九段色域延伸 三核心引擎 蓝光高清流媒体 重低音专业声场 SCM智能护眼技术', '1', '2019-06-19 00:27:23', '19');
INSERT INTO product VALUES ('99', '容声(Ronshen) BCD-535WSS1HP 535升', '3888', '3666', 'products/dk1001.jpg', '【 618冰箱洗衣机狂欢节 】冰箱、洗衣机火爆低价！满额至高减2000，更多爆款直降！ [点击进入冰箱洗衣机专场]【容声535升对开门冰箱，32年品质传承-7度软冷冻，VC养鲜--畅想原生态！', '1', '2019-06-19 00:28:47', '20');
INSERT INTO product VALUES ('100', '西门子(siemens) WM12N1E80W', '3999', '3888', 'products/gt1001.jpg', ' 618冰箱洗衣机狂欢节 】冰箱、洗衣机火爆低价！满额至高减2000，更多爆款直降！ [点击进入冰箱洗衣机专场]中途添衣 专业除菌设计', '1', '2019-06-19 00:30:02', '21');
INSERT INTO product VALUES ('101', '博世(Bosch) WTW875600W 9公斤', '7999', '7888', 'products/gx1001.jpg', '【 618冰箱洗衣机狂欢节 】冰箱、洗衣机火爆低价！满额至高减2000，更多爆款直降！ [点击进入冰箱洗衣机专场]智能烘干 衣干即停 绒毛过滤系统', '1', '2019-06-19 00:31:25', '22');
INSERT INTO product VALUES ('102', '伊莱克斯(Electrolux) 1P 定频', '6777', '6555', 'products/bg1001.jpg', '定频 冷暖 壁挂式空EAW25FD13CA1\r\n【年中狂欢节】源自北欧，伊莱克斯冷', '1', '2019-06-19 00:32:50', '23');
INSERT INTO product VALUES ('103', '格力(GREE) 3匹 一级能效 智控WIFI', '8888', '8666', 'products/gs1001.jpg', '变频 舒享风 冷暖电辅 立柜式空调 KFR-72LW/(72554)FNhAb-A1', '1', '2019-06-19 00:33:54', '24');
INSERT INTO product VALUES ('104', '美的(Midea) 1.5匹 移动空调一体机', '2888', '2699', 'products/yd1001.jpg', ' KYR-35/N1Y-PD2 冷暖机 强制冷 厨房空调\r\n', '1', '2019-06-19 00:35:13', '25');

-- ----------------------------
-- Table structure for `user`
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `uid` int(11) NOT NULL auto_increment,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(255) default NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) default NULL,
  `addr` varchar(255) default NULL,
  `state` int(11) default NULL,
  `code` varchar(64) default NULL,
  PRIMARY KEY  (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO user VALUES ('10', 'jack', '123', '刘备', '347623882@qq.com', '18238736842', '北京市通州区光明路阳光小区23号', '0', null);
INSERT INTO user VALUES ('11', 'angela', '123', '张三', '23847297@qq.com', '13978342692', '南京市东西路', '0', null);
INSERT INTO user VALUES ('12', 'tom', '123', '汤姆', 'tom@sohu.com', '13587349284', '南通市通州区东海大道88号', '0', null);
INSERT INTO user VALUES ('13', 'sheldon', '123', '小明', '68344646@qq.com', '18965453446', '安徽省合肥市南京路阳光小区88号', '0', null);
INSERT INTO user VALUES ('14', 'Brad', '123', '布拉德皮特', '483085420@qq.com', '13554685648', '美国洛杉机布朗大道223号', '0', null);
INSERT INTO user VALUES ('15', 'zhangsan', '123456', '张三', '68713687@qq.com', '18256489874', '美国华盛顿阳光大道水之街872号', '0', null);
INSERT INTO user VALUES ('18', 'lisi', '123', '李四', '123@qq.com', '15555555555', '北京市昌平区', null, null);
