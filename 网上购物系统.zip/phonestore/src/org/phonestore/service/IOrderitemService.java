package org.phonestore.service;

import java.util.List;

public interface IOrderitemService {
	public List getOrderitemByOrderid(Integer orderid);
}
