package org.phonestore.service.impl;
import java.util.List;

import org.phonestore.dao.IOrderDAO;
import org.phonestore.service.IOrderService;
import org.phonestore.vo.Orders;
public class OrderService implements IOrderService{
	private IOrderDAO orderDAO;
	public void setOrderDAO(IOrderDAO orderDAO) {
		this.orderDAO=orderDAO;
	}
	public Orders saveOrder(Orders order) {
		return orderDAO.saveOrder(order);
	}
	@Override
	public List getOrdersByUserid(Integer userid) {
		// TODO Auto-generated method stub
		return orderDAO.getOrderByUserid(userid);
	}
	
	public List queryorderitems(int orderid)
	{
		return orderDAO.getRequiredbyOrderid(orderid);
	}
	
	
	@Override
	public List getAllOrdersByUserid(int userid) {
		return orderDAO.getAllOrdersByUserid(userid);
	}
	
}
