package org.phonestore.service.impl;
import org.phonestore.dao.IUserDAO;
import org.phonestore.service.IUserService;
import org.phonestore.vo.Admin;
import org.phonestore.vo.User;
public class UserService implements IUserService{
	private IUserDAO userDAO;
	public void saveUser(User user){
		this.userDAO.saveUser(user);
	}
	public User validateUser(String username,String password){
		return userDAO.validateUser(username, password);
	}
	public IUserDAO getUserDAO(){
		return userDAO;
	}
	public void setUserDAO(IUserDAO userDAO){
		this.userDAO=userDAO;
	}
	@Override
	public Admin AdminLogin(String adminname, String password) {
		// TODO Auto-generated method stub
		return userDAO.AdminLogin(adminname,password);
	}
}
