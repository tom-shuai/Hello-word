package org.phonestore.service.impl;

import java.util.List;

import org.phonestore.dao.BaseDAO;
import org.phonestore.dao.IOrderitemDAO;
import org.phonestore.service.IOrderitemService;

public class OrderitemService extends BaseDAO implements IOrderitemService{
	IOrderitemDAO orderitemDAO;
	@Override
	public List getOrderitemByOrderid(Integer orderid) {
		// TODO Auto-generated method stub
		return orderitemDAO.getOrderitemByOrderid(orderid);
	}
	public IOrderitemDAO getOrderitemDAO() {
		return orderitemDAO;
	}
	public void setOrderitemDAO(IOrderitemDAO orderitemDAO) {
		this.orderitemDAO = orderitemDAO;
	}
	
}
