package org.phonestore.service.impl;


import java.util.List;

import javax.persistence.Entity;
import javax.persistence.ManyToOne;

import org.phonestore.dao.MyDao;
import org.phonestore.service.LoginService;
import org.phonestore.vo.Catalog;
import org.phonestore.vo.Phone;
@Entity
public class LoginServiceImpl implements LoginService{
 
	@ManyToOne
	private MyDao mydao;
	public MyDao getMydao() {
		return mydao;
	}
	public void setMydao(MyDao mydao) {
		this.mydao = mydao;
	}
	public List<Phone> serch() {
		// TODO Auto-generated method stub
		return mydao.serch();
	}
	public int add(String phonename, int price, String picture) {
		// TODO Auto-generated method stub
		return mydao.add(phonename,price, picture);
	}
	public int update(int phoneid,int price) {
		// TODO Auto-generated method stub
		return mydao.update(phoneid,price);
	}
	
	public int delete(int phoneid) {
		// TODO Auto-generated method stub
		return mydao.delete(phoneid);
	}


}