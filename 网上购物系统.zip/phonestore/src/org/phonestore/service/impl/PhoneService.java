package org.phonestore.service.impl;
import java.util.List;
import org.phonestore.dao.IPhoneDAO;
import org.phonestore.service.IPhoneService;
import org.phonestore.vo.Phone;
public class PhoneService implements IPhoneService{
	private IPhoneDAO phoneDAO;
	public List getPhonebyCatalogid(Integer catalogid){
		return phoneDAO.getPhonebyCatalogid(catalogid);
	}
	public List getPhonebyCatalogidPaging(Integer catalogid,int currentPage,int pageSize){
		return phoneDAO.getPhonebyCatalogidPaging(catalogid, currentPage, pageSize);
	}
	public int getTotalbyCatalog(Integer catalogid){
		return phoneDAO.getTotalbyCatalog(catalogid);
	}
	public List getRequiredPhonebyHql(String hql,int currentPage,int pageSize) {
		return phoneDAO.getRequiredPhonebyHql(hql,currentPage,pageSize);
	}
	@Override
	public List getIceboxByPrice(Integer minPrice, Integer maxPrice,
			int currentPage, int pageSize) {
		// TODO Auto-generated method stub
		return phoneDAO.getPhoneByPrice(minPrice, maxPrice, currentPage, pageSize);
	}
	public int getIceboxByPrice(Integer minPrice, Integer maxPrice) {
		return phoneDAO.getPhoneByPrice(minPrice, maxPrice);
	}
	public IPhoneDAO getPhoneDAO() {
		return phoneDAO;
	}
	public void setPhoneDAO(IPhoneDAO phoneDAO) {
		this.phoneDAO=phoneDAO;
	}
	public Phone getPhonebyId(Integer phoneid){
		return phoneDAO.getPhonebyId(phoneid);
	}
	@Override
	public int getAllPhoneByHql(String hql) {
		// TODO Auto-generated method stub
		return phoneDAO.getAllPhoneByHql(hql);
	}

}
