package org.phonestore.service;

import java.util.List;

import org.phonestore.vo.Phone;

public interface LoginService {
	public List<Phone> serch();
	public int add(String phonename, int price, String picture);
	public int update(int phoneid,int price);
	public int delete(int phoneid);
}
