package org.phonestore.service;
import java.util.List;

import org.phonestore.vo.Phone;
public interface IPhoneService {
	public List getPhonebyCatalogid(Integer catalogid);
	public List getPhonebyCatalogidPaging(Integer catalogid,int currentPage,int pageSize);
	public int getTotalbyCatalog(Integer catalogid);
	public List getRequiredPhonebyHql(String hql,int currentPage,int pageSize);
	public int getAllPhoneByHql(String hql);
	public Phone getPhonebyId(Integer phoneid);
	public List getIceboxByPrice(Integer minPrice,Integer maxPrice,int currentPage,int pageSize);
	public int getIceboxByPrice(Integer minPrice, Integer maxPrice);
}
