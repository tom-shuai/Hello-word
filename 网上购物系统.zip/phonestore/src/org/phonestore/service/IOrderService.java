package org.phonestore.service;
import java.util.List;

import org.phonestore.vo.Orders;
public interface IOrderService {
	public Orders saveOrder(Orders order);
	
	public List getOrdersByUserid(Integer userid);
	
	public List getAllOrdersByUserid(int userid);
	public List queryorderitems(int orderid);
	
}
