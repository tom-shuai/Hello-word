package org.phonestore.dao;
import java.util.List;

import org.phonestore.vo.Phone;
public interface IPhoneDAO {
	public List getPhonebyCatalogid(Integer catalogid);
	public List getPhonebyCatalogidPaging(Integer catalogid,int currentPage,int pageSize);
	public int getTotalbyCatalog(Integer catalogid);
	public List getRequiredPhonebyHql(String hql,int currentPage,int pageSize);
	public int getAllPhoneByHql(String hql);
	public Phone getPhonebyId(Integer phoneid);
	public List getPhoneByPrice(Integer minPrice,Integer maxPrice,int currentPage,int pageSize);
	public int getPhoneByPrice(Integer minPrice,Integer maxPrice);
}
