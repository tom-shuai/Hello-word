package org.phonestore.dao;

import java.util.List;

public interface IOrderitemDAO {
	public List getOrderitemByOrderid(Integer orderid);
}
