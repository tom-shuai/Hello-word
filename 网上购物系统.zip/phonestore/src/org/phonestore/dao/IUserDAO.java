package org.phonestore.dao;
import org.phonestore.vo.Admin;
import org.phonestore.vo.User;
public interface IUserDAO {
	public void saveUser(User user);
	public User validateUser(String username,String password);
	public Admin AdminLogin(String adminname, String password);
}
