package org.phonestore.dao.impl;
import java.util.List;

import org.hibernate.*;
import org.phonestore.dao.*;
import org.phonestore.vo.Orders;
public class OrderDAO extends BaseDAO implements IOrderDAO{
	public Orders saveOrder(Orders order) {
		Session session = getSession();
		Transaction tx = session.beginTransaction();
		session.save(order);
		tx.commit();
		session.close();
		return order;
	}
	
	@Override
	public List getOrderByUserid(Integer userid) {		
		Session session=getSession();
		Query query=session.createQuery("from Orders o where o.user.userid=?");
		query.setParameter(0, userid);
		List orderss=query.list();
		session.close();
		return orderss;
	}
	

	public List getAllOrdersByUserid(int userid) {

		Session session = getSession();
		Query query = session
				.createQuery("from Orders o where o.user="+userid);
		List orders = query.list();
		session.close();
		return orders;
	}

	@Override
	public List getRequiredbyOrderid(int orderid) {
		Session session = getSession();
		String hql = "from Orderitem o,Phone p where o.orders="+orderid+"and o.phone=p.phoneid";
		Query query = session
				.createQuery(hql);
		List orders = query.list();
		session.close();		
		return orders;
	}

	

	
}
