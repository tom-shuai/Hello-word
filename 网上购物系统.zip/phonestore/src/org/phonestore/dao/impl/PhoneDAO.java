package org.phonestore.dao.impl;
import java.util.List;
import org.hibernate.*;
import org.phonestore.dao.*;
import org.phonestore.vo.Phone;
public class PhoneDAO extends BaseDAO implements IPhoneDAO{
	public List getPhonebyCatalogid(Integer catalogid){
		Session session=getSession();
		String hql="from Phone b where b.catalog.catalogid=?";
		Query query=session.createQuery(hql);
		query.setParameter(0, catalogid);
		List phones=query.list();
		session.close();
		return phones;
	}
	public List getPhonebyCatalogidPaging(Integer catalogid,int currentPage,int pageSize){
		Session session=getSession();
		Query query=session.createQuery("from Phone b where b.catalog.catalogid=?");
		query.setParameter(0, catalogid);
		//ȷ����ʼ�α��λ��
		int startRow=(currentPage-1)*pageSize;
		query.setFirstResult(startRow);
		query.setMaxResults(pageSize);
		List phones=query.list();
		session.close();
		return phones;
	}
	public int getTotalbyCatalog(Integer catalogid){
		Session session=getSession();
		Query query=session.createQuery("from Phone b where b.catalog.catalogid=?");
		query.setParameter(0,catalogid);
		List phones=query.list();
		int totalSize=phones.size();
		session.close();
		return totalSize;
	}
	public List getRequiredPhonebyHql(String hql,int currentPage,int pageSize) {
		Session session=getSession();
		Query query=session.createQuery(hql);
		int startRow=(currentPage-1)*pageSize;
		query.setFirstResult(startRow);
		query.setMaxResults(pageSize);
		List phones=query.list();
		session.close();
		return phones;
	}
	//����ͼ��ŵõ�ͼ��
	public Phone getPhonebyId(Integer phoneid){
		Session session=getSession();
		Phone phone=(Phone)session.get(Phone.class,phoneid);
		session.close();
		return phone;
	}
	@Override
	public int getAllPhoneByHql(String hql) {
		// TODO Auto-generated method stub
		Session session=getSession();
		Query query=session.createQuery(hql);
		List phones=query.list();
		int totalSize=phones.size();
		session.close();
		return totalSize;
	}
	@Override
	public List getPhoneByPrice(Integer minPrice, Integer maxPrice,
			int currentPage, int pageSize) {
		Session session=getSession();
		String hql;
		if(maxPrice==-1)hql="from Phone p where p.price>"+minPrice;
		else hql="from Phone p where p.price between "+minPrice+" and "+maxPrice;
		Query query=session.createQuery(hql);
		
		
		List phones=query.list();
		session.close();
		return phones;
	}
	@Override
	public int getPhoneByPrice(Integer minPrice, Integer maxPrice) {
		// TODO Auto-generated method stub
		Session session=getSession();
		String hql;
		if(maxPrice==-1)hql="from Phone p where p.price>"+minPrice;
		else hql="from Phone p where p.price between "+minPrice+" and "+maxPrice;
		Query query=session.createQuery(hql);
		List phones=query.list();
		int totalSize=phones.size();
		session.close();
		return totalSize;
	}
}
