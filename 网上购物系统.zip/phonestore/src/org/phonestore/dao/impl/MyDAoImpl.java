package org.phonestore.dao.impl;
import java.util.ArrayList;
import java.util.List;
import org.hibernate.*;
import org.phonestore.dao.BaseDAO;
import org.phonestore.dao.MyDao;
import org.phonestore.vo.Phone;


public class MyDAoImpl extends BaseDAO implements MyDao {

	public Session session;

	public void getCurrentSession() {
		getSession();
	}

	public void closeSession() {
		if (session != null) {
			closeSession();
		}
	}
	public List<Phone> serch(){
		Session session=null;
		Transaction tx=null;	   
		List<Phone> list=null;
		try{
			session=getSession();
			tx=session.beginTransaction();
			list=session.createQuery("from Phone").list();
			tx.commit();
			session.close();
		}catch(Exception e){
			if(tx!=null)tx.rollback();
			e.printStackTrace();
		}
			return list;		
	}
	
	public int add(String phonename, int price, String picture){
		Session session=null;
		Transaction tx=null;
			session=getSession();
			tx=session.beginTransaction();
			Phone b=new Phone();
			b.setPhonename(phonename);
			b.setPrice(price);
			b.setPicture(picture);	
			session.save(b);
			tx.commit();
			session.close();
		return 1;
	}
	public int update(int phoneid, int price) {
		Session session=null;
		Transaction tx=null;
		Phone phone=null;
		try{
			session=getSession();
			tx=session.beginTransaction();
			phone=(Phone)session.createQuery("from Phone where phoneid="+phoneid).list().get(0);
	//		book=(Book)session.get(Book.class,bookid);
			phone.setPrice(price);
			session.update(phone);
			tx.commit();
			session.close();
		}catch(Exception e){
			if(tx!=null)tx.rollback();
			e.printStackTrace();
			return 0;
		}
		return 1;
	}
	
	public int delete(int phoneid){
		Session session=null;
		Transaction tx=null;
		try{
			session=getSession();
			tx=session.beginTransaction();
			Phone b=new Phone();
			b=(Phone)session.get(Phone.class,phoneid);			
			session.delete(b);
			tx.commit();
			session.close();
		}catch(Exception e){
			if(tx!=null)tx.rollback();
			e.printStackTrace();
			return 0;
		}
		return 1;
	}
	
}
