package org.phonestore.dao.impl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.phonestore.dao.BaseDAO;
import org.phonestore.dao.IOrderitemDAO;

public class OrderitemDAO extends BaseDAO implements IOrderitemDAO{

	@Override
	public List getOrderitemByOrderid(Integer orderid) {
		// TODO Auto-generated method stub
		Session session=getSession();
		Query query=session.createQuery("from Orderitem o where o.orders.orderid=?");
		query.setParameter(0, orderid);
		List orderitems=query.list();
		session.close();
		return orderitems;
	}

}
