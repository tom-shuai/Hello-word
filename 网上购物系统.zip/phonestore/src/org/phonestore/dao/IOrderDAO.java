package org.phonestore.dao;
import java.util.List;

import org.phonestore.vo.Orders;
public interface IOrderDAO {
	public Orders saveOrder(Orders order);
	public List getOrderByUserid(Integer userid);

	public List getRequiredbyOrderid(int orderid);
	
	
	
	public List getAllOrdersByUserid(int userid);
}
