package org.phonestore.action;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.phonestore.model.Cart;
import org.phonestore.service.IOrderService;
import org.phonestore.service.IOrderitemService;
import org.phonestore.service.IPhoneService;
import org.phonestore.vo.Orderitem;
import org.phonestore.vo.Orders;
import org.phonestore.vo.Phone;
import org.phonestore.vo.User;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class OrdersAction extends ActionSupport{
	Integer userid;
	Integer orderid;
	IOrderService orderService;
	IOrderitemService orderitemService;
	IPhoneService phoneService;
	public String showIndent()throws Exception{
		List orders=orderService.getOrdersByUserid(userid);
		Map session=ActionContext.getContext().getSession();
		User user=(User)session.get("user");
		if(user==null)
			return ActionSupport.ERROR;
		List order_orderitem= null;
		List orderitems=new ArrayList();
		Indent orderitem1=new Indent();
		Phone phone;
		Orderitem orderitem;
		Orders order;
		Integer payMoney=0;
		for(int i=0;i<orders.size();i++){
			payMoney=0;
			order=(Orders)orders.get(i);
			order_orderitem=orderitemService.getOrderitemByOrderid(order.getOrderid());
			for(int j=0;j<order_orderitem.size();j++){
				orderitem=(Orderitem)order_orderitem.get(j);
				phone=phoneService.getPhonebyId(orderitem.getPhone().getPhoneid());
				orderitem.setPhone(phone);
				payMoney=payMoney+phone.getPrice()*orderitem.getQuantity();
			}
			orderitem1=new Indent();
			orderitem1.setOrderid(order.getOrderid());
			orderitem1.setTime(order.getOrderdate());
			orderitem1.setOrderitem(order_orderitem);
			orderitem1.setPayMoney(payMoney);
			orderitems.add(orderitem1);
		}		
		Map request=(Map)ActionContext.getContext().get("request");
		request.put("orderitems", orderitems);
		return SUCCESS;
	}
	public Integer getUserid() {
		return userid;
	}

	public void setUserid(Integer userid) {
		this.userid = userid;
	}
	public IOrderService getOrderService() {
		return orderService;
	}
	public void setOrderService(IOrderService orderService) {
		this.orderService = orderService;
	}
	public IOrderitemService getOrderitemService() {
		return orderitemService;
	}
	public void setOrderitemService(IOrderitemService orderitemService) {
		this.orderitemService = orderitemService;
	}
	public Integer getOrderid() {
		return orderid;
	}
	public void setOrderid(Integer orderid) {
		this.orderid = orderid;
	}
	public IPhoneService getPhoneService() {
		return phoneService;
	}
	public void setPhoneService(IPhoneService phoneService) {
		this.phoneService = phoneService;
	}
	
}
