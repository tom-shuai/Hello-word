package org.phonestore.action;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Indent {
	Integer orderid;
	List orderitem=new ArrayList();
	Integer payMoney;
	Date time;
	public Integer getOrderid() {
		return orderid;
	}
	public void setOrderid(Integer orderid) {
		this.orderid = orderid;
	}
	public List getOrderitem() {
		return orderitem;
	}
	public void setOrderitem(List orderitem) {
		this.orderitem = orderitem;
	}
	public Integer getPayMoney() {
		return payMoney;
	}
	public void setPayMoney(Integer payMoney) {
		this.payMoney = payMoney;
	}
	public Date getTime() {
		return time;
	}
	public void setTime(Date time) {
		this.time = time;
	}
	
}
