package org.phonestore.action;
import java.util.*;
import com.opensymphony.xwork2.*;
import org.phonestore.service.ICatalogService;
import org.phonestore.service.IPhoneService;
import org.phonestore.util.Pager;
public class PhoneAction extends ActionSupport{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	protected ICatalogService catalogService;
	protected IPhoneService phoneService;
	protected Integer catalogid;
	private Integer currentPage=1;
	private String phonename;
	Integer minPrice,maxPrice;
	public String browseCatalog() throws Exception{
		List catalogs=catalogService.getAllCatalogs();
		Map request=(Map)ActionContext.getContext().get("request");
		request.put("catalogs", catalogs);
		return SUCCESS;
	}
	public String browsePhone() throws Exception{
		List phones=phoneService.getPhonebyCatalogid(catalogid);
		Map request=(Map)ActionContext.getContext().get("request");
		request.put("phones", phones);
		return SUCCESS;
	}
	public String browsePhonePaging() throws Exception{
		int totalSize=phoneService.getTotalbyCatalog(catalogid);
		Pager pager=new Pager(currentPage,totalSize);
		List phones=phoneService.getPhonebyCatalogidPaging(catalogid,currentPage, pager.getPageSize());
		Map request=(Map)ActionContext.getContext().get("request");
		request.put("phones", phones);
		request.put("pager",pager);
		//���ﳵҪ����ʱ,��Ҫ��ס���صĵ�ַ
		Map session=ActionContext.getContext().getSession();
		request.put("catalogid",catalogid);
		return SUCCESS;
	}
	
	public String indexbrowsePhonePaging() throws Exception{
		int totalSize=phoneService.getTotalbyCatalog(1);
		Pager pager=new Pager(currentPage,totalSize);
		List phones=phoneService.getPhonebyCatalogidPaging(1,currentPage, pager.getPageSize());
		Map request=(Map)ActionContext.getContext().get("request");
		request.put("phones", phones);
		request.put("pager",pager);
		//���ﳵҪ����ʱ,��Ҫ��ס���صĵ�ַ
		Map session=ActionContext.getContext().getSession();
		request.put("catalogid",1);
		return SUCCESS;
	}
	
	public String searchPhone() throws Exception {
		StringBuffer hql=new StringBuffer("from Phone p ");
		if(!phonename.isEmpty())
			hql.append("where p.phonename like '%"+phonename+"%'");
		int totalSize=phoneService.getAllPhoneByHql(hql.toString());
		Pager pager=new Pager(currentPage,totalSize);
		List phones=phoneService.getRequiredPhonebyHql(hql.toString(),currentPage,pager.getPageSize());
		Map request=(Map)ActionContext.getContext().get("request");
		request.put("phones",phones);
		request.put("pager",pager);
		Map session=ActionContext.getContext().getSession();
		request.put("catalogid",1);
		return SUCCESS;
	}
	public String getPhoneByPrice()throws Exception{
		if (getMinPrice()==null || getMaxPrice() == null ) {
			return ERROR;
		}
		int totalSize=phoneService.getIceboxByPrice(minPrice, maxPrice);
		Pager pager=new Pager(currentPage,totalSize);
		List phones=phoneService.getIceboxByPrice(minPrice,maxPrice,currentPage, pager.getPageSize());
		Map request=(Map)ActionContext.getContext().get("request");
		request.put("phones", phones);
		request.put("pager",pager);
		return SUCCESS;
	}
	
	public Integer getCatalogid(){
		return this.catalogid;
	}
	public void setCatalogid(Integer catalogid){
		this.catalogid=catalogid;
	}
	
	public ICatalogService getCatalogService(){
		return this.catalogService;
	}
	public void setCatalogService(ICatalogService catalogService){
		this.catalogService=catalogService;
	}
	
	public IPhoneService getPhoneService(){
		return phoneService;
	} 
	public void setPhoneService(IPhoneService phoneService){
		this.phoneService=phoneService;
	}

	public Integer getCurrentPage() {
		return currentPage;
	}
	public void setCurrentPage(Integer currentPage) {
		this.currentPage=currentPage;
	}
	
	public String getPhonename() {
		return phonename;
	}
	public void setPhonename(String phonename) {
		this.phonename=phonename;
	}
	public Integer getMinPrice() {
		return minPrice;
	}
	public void setMinPrice(Integer minPrice) {
		this.minPrice = minPrice;
	}
	public Integer getMaxPrice() {
		return maxPrice;
	}
	public void setMaxPrice(Integer maxPrice) {
		this.maxPrice = maxPrice;
	}
	
}
