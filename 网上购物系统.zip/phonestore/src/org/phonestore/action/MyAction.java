package org.phonestore.action;

import java.util.Map;

import org.hibernate.Query;
import org.hibernate.Session;
import org.phonestore.dao.BaseDAO;
import org.phonestore.service.LoginService;
import org.phonestore.vo.Admin;
import org.phonestore.vo.Phone;

import antlr.collections.List;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
public class MyAction extends ActionSupport{
	private Phone phone;
	//private String columnName,value;
	private LoginService loginservice;
	private java.util.List<Phone> l=null;

	
	
	
	public LoginService getLoginservice() {
		return loginservice;
	}

	public void setLoginservice(LoginService loginservice) {
		this.loginservice = loginservice;
	}

	public String execute() throws Exception{
		l=loginservice.serch();
		if(l!=null){
			Map session = ActionContext.getContext().getSession();	//��ûỰ���������浱ǰ��¼�û�����Ϣ
			session.put("list", l);
			return "success";
		}
		else{
			return ERROR;											//��֤ʧ�ܷ����ַ���ERROR
		}	
	}

	public String insert() throws Exception{
		//AddDao u=new AddDaoImpl();
		int i=loginservice.add(phone.getPhonename(),phone.getPrice(),phone.getPicture());
		if(i>0) 
			return SUCCESS;
		else    
			return ERROR;
	}
	public String update() throws Exception{
		//UpdateDao u=new UpdateDaoImpl();
		int i=loginservice.update(phone.getPhoneid(), phone.getPrice());
		if(i>0) return SUCCESS;
		else    
			return ERROR;
	}

	public String delete() throws Exception{
		//DeleteDao u=new DeleteDaoImpl();
		int i=loginservice.delete(phone.getPhoneid());
		if(i>0) 
			return SUCCESS;
		else  
			return ERROR;
	}

	public Phone getPhone() {
		return phone;
	}

	public void setPhone(Phone phone) {
		this.phone = phone;
	}

	public java.util.List<Phone> getL() {
		return l;
	}

	public void setL(java.util.List<Phone> l) {
		this.l = l;
	}

	

}
