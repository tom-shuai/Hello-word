package org.phonestore.action;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.phonestore.model.Cart;
import org.phonestore.service.IOrderService;
import org.phonestore.service.IPhoneService;
import org.phonestore.vo.Orderitem;
import org.phonestore.vo.Orders;
import org.phonestore.vo.Phone;
import org.phonestore.vo.User;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
public class ShoppingAction extends ActionSupport{
	private int quantity;
	private Integer phoneid;
	private IPhoneService phoneService;
	private IOrderService orderService;
	private int userid;
	private int orderid;
	//���ӵ����ﳵ
	public String addToCart() throws Exception{
		Phone phone=phoneService.getPhonebyId(phoneid);
		Orderitem orderitem=new Orderitem();
		orderitem.setPhone(phone);
		orderitem.setQuantity(quantity);
		Map session=ActionContext.getContext().getSession();
		Cart cart=(Cart)session.get("cart");
		if(cart==null){
			cart=new Cart();
		}
		cart.addPhone(phoneid, orderitem);
		session.put("cart",cart);
		return SUCCESS;
	}
	
	//���¹��ﳵ
	public String updateCart() throws Exception{
		Map session=ActionContext.getContext().getSession();
		Cart cart=(Cart)session.get("cart");
		cart.updateCart(phoneid, this.getQuantity());
		session.put("cart", cart);
		return SUCCESS;
	}

	public String checkout() throws Exception{
		Map session=ActionContext.getContext().getSession();
		User user=(User)session.get("user");
		Cart cart=(Cart)session.get("cart");
		if(user==null || cart ==null)
			return ActionSupport.ERROR;
		Orders order=new Orders();
		order.setOrderdate(new Date());
		order.setUser(user);
		for(Iterator it=cart.getItems().values().iterator();it.hasNext();){
			Orderitem orderitem=(Orderitem)it.next();
			orderitem.setOrders(order);
			order.getOrderitems().add(orderitem);
		}
		orderService.saveOrder(order);
		Map request=(Map)ActionContext.getContext().get("request");
		request.put("order",order);
		session.remove("cart");
		return SUCCESS;
	}
	
	public String getOrders() throws Exception {
		Map session = ActionContext.getContext().getSession();
		User user = (User) session.get("user");
		if (user == null)
			return ActionSupport.ERROR;
		List orders = orderService.getAllOrdersByUserid(getUserid());
		Map request = (Map) ActionContext.getContext().get("request");
		request.put("orders", orders);
		return SUCCESS;
	}
	
	public String queryorderitems() throws Exception {
		List orderitems=orderService.queryorderitems(getOrderid());
		Map request=(Map)ActionContext.getContext().get("request");
		request.put("orderitems",orderitems);
		request.put("orderid",getOrderid());
		Map session=ActionContext.getContext().getSession();
		session.put("orderid",getOrderid());
		return SUCCESS;
	}

	public Integer getPhoneid() {
		return phoneid;
	}
	public void setPhoneid(Integer phoneid) {
		this.phoneid=phoneid;
	}
	
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity=quantity;
	}
	
	public IPhoneService getPhoneService() {
		return phoneService;
	}
	public void setPhoneService(IPhoneService phoneService) {
		this.phoneService=phoneService;
	}

	public IOrderService getOrderService() {
		return orderService;
	}
	public void setOrderService(IOrderService orderService) {
		this.orderService=orderService;
	}
	
	public int getUserid() {
		return userid;
	}
	
	public void setUserid(int userid) {
		this.userid = userid;
	}
	public int getOrderid() {
		return orderid;
	}
	
	public void setOrderid(int orderid) {
		this.orderid = orderid;
	}
}
