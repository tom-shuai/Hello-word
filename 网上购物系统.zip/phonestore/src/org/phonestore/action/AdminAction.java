package org.phonestore.action;

import java.util.Map;

import org.phonestore.service.IUserService;
import org.phonestore.vo.Admin;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class AdminAction extends ActionSupport{
	private Admin admin;
	protected IUserService userService;
	
	//�û���¼������service���validateUser()����
	public String execute() throws Exception{
		Admin a=userService.AdminLogin(admin.getAdminname(),admin.getPassword());
		if(a!=null)
		{
			Map session=ActionContext.getContext().getSession();
			//����˴λỰ��u���û��˺ţ���Ϣ
			session.put("admin", a);
			return SUCCESS;
		}
		return ERROR;
	}

	public Admin getAdmin() {
		return admin;
	}

	public void setAdmin(Admin admin) {
		this.admin = admin;
	}

	public IUserService getUserService(){
		return this.userService;
	}
	public void setUserService(IUserService userService){
		this.userService=userService;
	}

}