package com.xxx.proj.service;

public interface UserService {
    public String getName();
}
