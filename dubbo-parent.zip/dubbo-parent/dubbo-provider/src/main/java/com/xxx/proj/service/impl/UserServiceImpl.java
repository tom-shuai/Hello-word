package com.xxx.proj.service.impl;

import com.alibaba.dubbo.config.annotation.Service;
import com.xxx.proj.service.UserService;

//过去服务层注解：import org.springframework.stereotype.Service;
//现在服务层注解：import com.alibaba.dubbo.config.annotation.Service;
@Service
public class UserServiceImpl implements UserService {
    @Override
    public String getName() {
        return "我是XXX";
    }
}
