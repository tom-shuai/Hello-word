package com.xxx.proj.controller;

import com.alibaba.dubbo.config.annotation.Reference;
import com.xxx.proj.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

//@RestController=  @Controller + @ResponseBody
@Controller
public class UserController {
    //import com.alibaba.dubbo.config.annotation.Reference;
//    和com.alibaba.dubbo.config.annotation.Service;配套使用
    @Reference
    private UserService userService;

    @RequestMapping("/getName")
    @ResponseBody
    public String getName() {
        return userService.getName();
    }
}
